What works: scenes, camera(s), rendering of all windows
            gall gui controls (models rotation, translation, camera near far)
            mouse controls
What does not work: NDC Coordinates
                    Moving middle teddy does not move the other teddys
                    